<?php
namespace inc;
Class Mahasiswa {
    function __construct(){
         echo "Saya inc/Mahasiswa.php";
    }
}