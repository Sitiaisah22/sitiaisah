<?php

include "app/Mahasiswa.php";
include "inc/Mahasiswa.php";
include "layout/Mahasiswa.php";

$app = new App\Mahasiswa();
echo "<br>";
$inc = new inc\Mahasiswa();
echo "<br>";
$layout = new layout\Mahasiswa();