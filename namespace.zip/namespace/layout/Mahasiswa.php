<?php
namespace layout;
Class Mahasiswa {
    function __construct(){
         echo "Saya layout/Mahasiswa.php";
    }
}