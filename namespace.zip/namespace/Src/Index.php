<?php

require "vendor/autoload.php";


use Calculator\Calculator;
use Mobil\Mobil;
use Mobil\Toyota;
use Mobil\Honda;

$toyota = new Toyota("test", 10);
$Calculator = new Calculator($toyota);
echo "Jarak maksimum".$Calculator->hitungjarak();


